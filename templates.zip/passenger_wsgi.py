import sys
import os

# Добавляем путь к виртуальному окружению
INTERP = os.path.expanduser("/home/username/venv/bin/python")
if sys.executable != INTERP:
    os.execl(INTERP, INTERP, *sys.argv)

# Добавляем путь к директории проекта
sys.path.append(os.getcwd())

# Импортируем приложение
from app import app as application 